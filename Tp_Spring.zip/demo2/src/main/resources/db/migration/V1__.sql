CREATE TABLE band
(
    id           BIGINT AUTO_INCREMENT   NOT NULL,
    band_name    VARCHAR(255) NULL,
    formed_date  timestamp DEFAULT NOW() NULL,
    updated_date timestamp DEFAULT NOW() NULL,
    CONSTRAINT `PRIMARY` PRIMARY KEY (id)
);

CREATE TABLE band_musician
(
    band_id     BIGINT    DEFAULT 0 NOT NULL,
    musician_id BIGINT    DEFAULT 0 NOT NULL,
    join_date   timestamp DEFAULT NOW() NULL,
    CONSTRAINT `PRIMARY` PRIMARY KEY (band_id, musician_id)
);

CREATE TABLE musician
(
    id             BIGINT AUTO_INCREMENT   NOT NULL,
    person_id      BIGINT NULL,
    insertion_date timestamp DEFAULT NOW() NULL,
    updated_date   timestamp DEFAULT NOW() NULL,
    CONSTRAINT `PRIMARY` PRIMARY KEY (id)
);

CREATE TABLE person
(
    id            BIGINT AUTO_INCREMENT   NOT NULL,
    first_name    VARCHAR(255) NULL,
    last_name     VARCHAR(255) NULL,
    email         VARCHAR(255) NULL,
    age           INT NULL,
    inserted_date timestamp DEFAULT NOW() NULL,
    updated_date  timestamp DEFAULT NOW() NULL,
    CONSTRAINT `PRIMARY` PRIMARY KEY (id)
);

CREATE TABLE Instrument (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);


CREATE INDEX musician_id ON band_musician (musician_id);

CREATE INDEX person_id ON musician (person_id);