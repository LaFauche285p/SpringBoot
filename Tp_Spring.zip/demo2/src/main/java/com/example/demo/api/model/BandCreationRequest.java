package com.example.demo.api.model;

public record BandCreationRequest(String bandName) {

}

