package com.example.demo.api.model;

public class MusicianNotFoundException extends Throwable {
    public MusicianNotFoundException() {
        super("Musician non trouvé");
    }

    public MusicianNotFoundException(String message) {
        super(message);
    }
}
