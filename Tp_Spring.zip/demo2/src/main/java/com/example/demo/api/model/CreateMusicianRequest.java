package com.example.demo.api.model;

public record CreateMusicianRequest(String firstName, String lastName, String email, int age) {

}