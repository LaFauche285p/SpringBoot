package com.example.demo.repository;

public class Band {
}
