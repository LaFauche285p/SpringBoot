package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
public class MusicianInstrument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Musician musician;

    @ManyToOne
    private Instrument instrument;

    public MusicianInstrument() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Musician getMusician() {
        return musician;
    }

    public void setMusician(Musician musician) {
        this.musician = musician;
    }

    public Instrument getInstrument() {
        return instrument;
    }

    public void setInstrument(Instrument instrument) {
        this.instrument = instrument;
    }

    @Override
    public String toString() {
        return "MusicianInstrument{" +
                "id=" + id +
                ", musician=" + musician +
                ", instrument=" + instrument +
                '}';
    }
}
