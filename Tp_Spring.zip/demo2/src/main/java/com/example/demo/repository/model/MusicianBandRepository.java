package com.example.demo.repository.model;

public interface MusicianBandRepository {

}
