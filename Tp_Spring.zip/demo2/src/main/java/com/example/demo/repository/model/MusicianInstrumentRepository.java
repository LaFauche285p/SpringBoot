package com.example.demo.repository.model;

import com.example.demo.entity.MusicianInstrument;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MusicianInstrumentRepository extends JpaRepository<MusicianInstrument, Long> {}
