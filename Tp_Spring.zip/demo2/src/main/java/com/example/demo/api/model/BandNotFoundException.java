package com.example.demo.api.model;

public class BandNotFoundException extends RuntimeException {
    public BandNotFoundException() {
        super("Bande non trouvé");
    }
}
