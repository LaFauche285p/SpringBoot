package com.example.demo.service;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

public class FestivalController {

    private FestivalController festivalService;

    @PostMapping("/festivals/{festivalId}/bands/{bandId}")
    public void addBandToFestival(@PathVariable Long festivalId, @PathVariable Long bandId) {
        festivalService.addBandToFestival(festivalId, bandId);
    }
}
